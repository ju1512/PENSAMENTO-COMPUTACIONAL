let carX = 400;

function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(135, 206, 235); // céu azul

  // Linha divisória central
  stroke(0);
  strokeWeight(2);
  line(width / 2, 0, width / 2, height);

  // ------------------ CAMPO (lado esquerdo) ------------------
  noStroke();
  fill(34, 139, 34); // grama
  rect(0, height / 2, width / 2, height / 2);

  // Sol
  fill(255, 204, 0);
  ellipse(100, 100, 80, 80);

  // Árvore
  fill(139, 69, 19); // tronco
  rect(120, 260, 20, 60);
  fill(34, 139, 34); // copa
  ellipse(130, 250, 60, 60);

  // Boi
  fill(139, 69, 19); // corpo
  rect(180, 310, 60, 30);
  fill(0); // pernas
  rect(185, 340, 5, 20);
  rect(210, 340, 5, 20);
  fill(139, 69, 19); // cabeça
  ellipse(170, 320, 20, 20);
  fill(255); // olhos
  ellipse(167, 318, 5, 5);
  ellipse(173, 318, 5, 5);
  fill(0); // pupilas
  ellipse(167, 318, 2, 2);
  ellipse(173, 318, 2, 2);

  // ------------------ CIDADE (lado direito) ------------------
  fill(169, 169, 169); // calçada
  rect(width / 2, height / 2, width / 2, height / 2);

  // Prédio 1
  fill(100);
  rect(450, 200, 80, 180);
  fill(255);
  for (let y = 220; y < 360; y += 30) {
    rect(460, y, 20, 20);
    rect(490, y, 20, 20);
  }

  // Prédio 2
  fill(80);
  rect(600, 150, 60, 230);
  fill(255);
  for (let y = 170; y < 360; y += 30) {
    rect(610, y, 15, 15);
    rect(630, y, 15, 15);
  }

  // Rua
  fill(50);
  rect(width / 2, height - 60, width / 2, 40);
  stroke(255);
  strokeWeight(2);
  for (let x = width / 2 + 10; x < width; x += 40) {
    line(x, height - 40, x + 20, height - 40);
  }

  // Carro animado
  noStroke();
  fill(255, 0, 0); // carro
  rect(carX, height - 80, 60, 30);
  fill(0); // rodas
  ellipse(carX + 10, height - 50, 15, 15);
  ellipse(carX + 50, height - 50, 15, 15);

  // Movimento do carro
  carX += 2;
  if (carX > width) {
    carX = width / 2; // reinicia ao início da cidade
  }
}